export const BASE_API_URL =
  "https://onufemme-admin-ws.f9tkixr0bx6.eu-gb.codeengine.appdomain.cloud";
// export const BASE_API_URL = "10.200.11.244:3000";
