const data = [
  {
    title: "Televisions",
    id: 1,
    img: "/images/categories/categories-01.png",
  },
  {
    title: "Laptop & PC",
    id: 2,
    img: "/images/categories/categories-02.png",
  },
  {
    title: "Mobile & Tablets",
    id: 3,
    img: "/images/categories/categories-03.png",
  },
  {
    title: "Games & Videos",
    id: 4,
    img: "/images/categories/categories-04.png",
  },
  {
    title: "Home Appliances",
    id: 5,
    img: "/images/categories/categories-05.png",
  },
  {
    title: "Health & Sports",
    id: 6,
    img: "/images/categories/categories-06.png",
  },
  {
    title: "Watches",
    id: 7,
    img: "/images/categories/categories-07.png",
  },
  {
    title: "Televisions",
    id: 8,
    img: "/images/categories/categories-04.png",
  },
];

export default data;
